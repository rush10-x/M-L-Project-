# app.py
# Streamlit web application for cryptocurrency volatility prediction.
# This app loads a pre-trained model and scaler to make predictions on new data.

import streamlit as st # Moved to the very top to ensure 'st' is defined

# --- Streamlit Page Configuration (MUST be the first Streamlit command) ---
st.set_page_config(layout="wide", page_title="Crypto Volatility Predictor")

import pandas as pd
import joblib
import os
import numpy as np

# Import necessary functions from your src modules
# Ensure these functions are robust enough to handle single-row or small dataframes for prediction
from src.data_processing import handle_missing_values, normalize_features # Only need parts for prediction
from src.feature_engineering import engineer_features, calculate_daily_returns, \
                                    calculate_rolling_volatility, calculate_moving_averages, \
                                    calculate_liquidity_ratio, add_technical_indicators

# --- Configuration for Model Loading ---
MODELS_DIR = 'models'
MODEL_PATH = os.path.join(MODELS_DIR, 'volatility_predictor.pkl')
SCALER_PATH = os.path.join(MODELS_DIR, 'data_scaler.pkl')
FEATURES_LIST_PATH = os.path.join(MODELS_DIR, 'features_list.pkl')

# Features that were normalized during training (must match `main.py` and `data_processing.py`)
FEATURES_TO_NORMALIZE_FOR_PREDICTION = ['Open', 'High', 'Low', 'Close', 'Volume', 'Marketcap'] # Corrected 'Market Cap' to 'Marketcap'

@st.cache_resource # Cache the model loading for efficiency
def load_ml_artifacts():
    """
    Loads the trained machine learning model, data scaler, and feature list.
    Uses st.cache_resource to avoid reloading on every rerun.
    """
    try:
        model = joblib.load(MODEL_PATH)
        scaler = joblib.load(SCALER_PATH)
        features_list = joblib.load(FEATURES_LIST_PATH)
        st.success("Machine Learning Model and artifacts loaded successfully!")
        return model, scaler, features_list
    except FileNotFoundError as e:
        st.error(f"Error: Essential model files not found. Please run `python main.py` first to train and save them. Missing: {e}")
        st.stop() # Stop execution if critical files are missing
    except Exception as e:
        st.error(f"An unexpected error occurred while loading ML artifacts: {e}")
        st.stop()

# Load model artifacts when the app starts
model, data_scaler, model_features = load_ml_artifacts()

st.markdown(
    """
    <style>
    .main {
        background-color: #f0f2f6;
        padding: 20px;
        border-radius: 10px;
    }
    .stButton>button {
        background-color: #4CAF50;
        color: white;
        border-radius: 8px;
        padding: 10px 20px;
        font-size: 16px;
        box-shadow: 2px 2px 5px rgba(0,0,0,0.2);
    }
    .stButton>button:hover {
        background-color: #45a049;
    }
    .stFileUploader {
        border: 2px dashed #4CAF50;
        border-radius: 8px;
        padding: 20px;
        text-align: center;
    }
    .stAlert {
        border-radius: 8px;
    }
    h1, h2, h3 {
        color: #2c3e50;
        text-align: center;
    }
    .dataframe-container {
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 10px;
        background-color: white;
        box-shadow: 1px 1px 3px rgba(0,0,0,0.1);
    }
    </style>
    """,
    unsafe_allow_html=True
)

st.title("📈 Cryptocurrency Volatility Prediction")
st.write("Upload your historical cryptocurrency data (CSV) to predict future volatility levels.")

st.info("Please ensure your CSV file contains 'Date', 'Symbol', 'Open', 'High', 'Low', 'Close', 'Volume', and 'Marketcap' columns.") # Corrected info message

uploaded_file = st.file_uploader("Upload Historical Crypto Data (CSV)", type="csv")

if uploaded_file is not None:
    try:
        # Read the uploaded CSV file
        input_df_raw = pd.read_csv(uploaded_file)
        
        st.subheader("1. Original Uploaded Data Preview")
        st.dataframe(input_df_raw.head())

        # --- Data Preprocessing (must match training pipeline) ---
        st.subheader("2. Preprocessing Data...")
        
        # Make a copy to avoid modifying the original uploaded DataFrame
        df_for_prediction = input_df_raw.copy()
        
        # Convert 'Date' column to datetime and sort
        df_for_prediction['Date'] = pd.to_datetime(df_for_prediction['Date'])
        df_for_prediction = df_for_prediction.sort_values(by=['Symbol', 'Date']).reset_index(drop=True)

        # Handle missing values (using the same strategy as in data_processing.py)
        df_for_prediction = handle_missing_values(df_for_prediction)
        
        # Apply normalization using the *loaded* scaler
        # Ensure that the columns exist before attempting to scale
        cols_to_scale_exist = [col for col in FEATURES_TO_NORMALIZE_FOR_PREDICTION if col in df_for_prediction.columns]
        if len(cols_to_scale_exist) != len(FEATURES_TO_NORMALIZE_FOR_PREDICTION):
            st.warning(f"Warning: Not all expected columns for normalization found in uploaded data. Expected: {FEATURES_TO_NORMALIZE_FOR_PREDICTION}, Found: {cols_to_scale_exist}")
        
        # Transform only the existing numerical features using the pre-fitted scaler
        df_for_prediction[cols_to_scale_exist] = data_scaler.transform(df_for_prediction[cols_to_scale_exist])
        
        st.write("Data after initial preprocessing (missing values handled, features normalized):")
        st.dataframe(df_for_prediction.head())

        # --- Feature Engineering (must match training pipeline) ---
        st.subheader("3. Engineering Features...")
        # Re-apply the same feature engineering steps using the imported functions
        # Ensure the order and logic are identical to `src/feature_engineering.py`
        df_engineered = engineer_features(df_for_prediction.copy())
        
        st.write("Data after feature engineering:")
        st.dataframe(df_engineered.head())
        
        # --- Prepare Data for Prediction ---
        st.subheader("4. Making Predictions...")
        
        # Ensure the DataFrame for prediction contains exactly the features the model was trained on
        # Use the `model_features` list loaded from `features_list.pkl`
        
        # Check if all required features are present in the engineered DataFrame
        missing_prediction_features = [f for f in model_features if f not in df_engineered.columns]
        if missing_prediction_features:
            st.error(f"Error: Missing required features for prediction. Please check your feature engineering. Missing: {missing_prediction_features}")
            st.stop()

        X_predict = df_engineered[model_features]
        
        # Handle any remaining NaNs that might have been introduced by feature engineering
        # (e.g., if the uploaded data is too short for rolling windows)
        initial_rows_count = len(X_predict)
        X_predict.dropna(inplace=True)
        if len(X_predict) < initial_rows_count:
            st.warning(f"Dropped {initial_rows_count - len(X_predict)} rows due to NaNs after feature engineering. "
                       "This might happen if your uploaded data is too short for rolling calculations.")
        
        if X_predict.empty:
            st.error("No valid data rows remaining after preparing features for prediction. "
                     "Please ensure your uploaded data has enough historical records.")
            st.stop()

        # Make predictions
        predictions = model.predict(X_predict)

        # Add predictions back to a new DataFrame for display
        # Align predictions with the original data based on the index of X_predict
        prediction_results_df = df_engineered.loc[X_predict.index].copy()
        prediction_results_df['Predicted_Volatility'] = predictions

        st.subheader("5. Volatility Predictions")
        st.write("Here are the predicted volatility levels for your cryptocurrency data:")
        
        # Display relevant columns, showing the last few predictions
        display_cols = ['Date', 'Symbol', 'Close', 'Rolling_Volatility', 'Predicted_Volatility']
        st.dataframe(prediction_results_df[display_cols].tail(20)) # Show last 20 predictions

        # Provide a download button for the full prediction results
        csv_data = prediction_results_df.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="Download Predictions CSV",
            data=csv_data,
            file_name='cryptocurrency_volatility_predictions.csv',
            mime='text/csv',
            help="Download the full dataset with predicted volatility."
        )

    except pd.errors.EmptyDataError:
        st.error("The uploaded file is empty. Please upload a CSV with data.")
    except KeyError as e:
        st.error(f"Missing expected column in your CSV: {e}. Please ensure your file has 'Date', 'Symbol', 'Open', 'High', 'Low', 'Close', 'Volume', and 'Marketcap' columns.") # Updated error message
    except Exception as e:
        st.error(f"An unexpected error occurred during processing: {e}")
        st.info("Please verify your CSV format and column names match the expected structure.")

st.markdown("---")
st.markdown("Developed for Cryptocurrency Volatility Prediction Project.")
