# src/model_training.py

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib # For saving/loading models and other objects
import numpy as np
import os

def define_target_variable(df, volatility_col='Rolling_Volatility', horizon=1):
    """
    Defines the target variable for volatility prediction.
    Predicts the volatility 'horizon' days into the future.

    Args:
        df (pd.DataFrame): DataFrame with 'Rolling_Volatility' column.
        volatility_col (str): The name of the volatility column to use as target.
        horizon (int): Number of days into the future to predict volatility.

    Returns:
        pd.DataFrame: DataFrame with 'Target_Volatility' column, with rows dropped where target is NaN.
    """
    # Shift the volatility column upwards by 'horizon' to get the future volatility
    # Group by Symbol to ensure shifting is done within each cryptocurrency's time series
    df['Target_Volatility'] = df.groupby('Symbol')[volatility_col].shift(-horizon)
    
    # Drop rows where the target volatility is NaN (these are the last 'horizon' rows for each symbol)
    df_with_target = df.dropna(subset=['Target_Volatility']).copy()
    
    print(f"Target variable '{volatility_col}' defined for {horizon} day(s) future. "
          f"Dropped {len(df) - len(df_with_target)} rows due to target NaN.")
    return df_with_target

def select_features_and_target(df, exclude_cols=['Date', 'Symbol', 'Daily_Return', 'Target_Volatility']):
    """
    Selects features (X) and target (y) for the model training.
    Ensures that only numerical columns are selected as features.

    Args:
        df (pd.DataFrame): The DataFrame containing features and target.
        exclude_cols (list): Columns to exclude from features (e.g., identifiers, intermediate calculations).

    Returns:
        tuple: (pd.DataFrame, pd.Series, list): X (features), y (target), and list of feature names used.
    """
    # Identify all columns that are not in the exclude list
    potential_features = [col for col in df.columns if col not in exclude_cols]
    
    # Filter for only numerical columns among the potential features
    # This is the key change to prevent string columns from being passed to the model
    X = df[potential_features].select_dtypes(include=np.number)
    
    # Get the actual list of features that were selected (numerical and not excluded)
    features = X.columns.tolist()

    # Ensure all selected features exist in the DataFrame (should be true after select_dtypes)
    missing_features = [f for f in features if f not in df.columns]
    if missing_features:
        # This warning should ideally not trigger if select_dtypes works as expected
        print(f"Warning: Some selected features are missing from the DataFrame: {missing_features}")

    y = df['Target_Volatility']
    
    print(f"Selected {len(features)} numerical features for training: {features}")
    return X, y, features

def train_model(X_train, y_train, model_type='RandomForest'):
    """
    Trains a selected machine learning model.

    Args:
        X_train (pd.DataFrame): Training features.
        y_train (pd.Series): Training target.
        model_type (str): Type of model to train ('LinearRegression', 'RandomForest', 'GradientBoosting').

    Returns:
        object: The trained machine learning model.
    """
    model = None
    if model_type == 'LinearRegression':
        model = LinearRegression()
    elif model_type == 'RandomForest':
        # RandomForestRegressor is robust and generally performs well.
        # n_jobs=-1 uses all available CPU cores for faster training.
        model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    elif model_type == 'GradientBoosting':
        # GradientBoostingRegressor can also be very effective.
        model = GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, max_depth=3, random_state=42)
    # Add more models as needed (e.g., XGBoost, LightGBM, or deep learning models like LSTMs if appropriate)
    else:
        raise ValueError(f"Model type '{model_type}' not supported. Choose from 'LinearRegression', 'RandomForest', 'GradientBoosting'.")

    print(f"Training {model_type} model...")
    model.fit(X_train, y_train)
    print(f"{model_type} model trained successfully.")
    return model

def evaluate_model(model, X_test, y_test):
    """
    Evaluates the model's performance using RMSE, MAE, and R² score.

    Args:
        model (object): The trained machine learning model.
        X_test (pd.DataFrame): Test features.
        y_test (pd.Series): Test target.

    Returns:
        tuple: (float, float, float, np.array): RMSE, MAE, R2 score, and predictions.
    """
    predictions = model.predict(X_test)
    
    rmse = np.sqrt(mean_squared_error(y_test, predictions))
    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)

    print(f"\n--- Model Evaluation ---")
    print(f"  Root Mean Squared Error (RMSE): {rmse:.4f}")
    print(f"  Mean Absolute Error (MAE): {mae:.4f}")
    print(f"  R-squared (R2) Score: {r2:.4f}")
    print("------------------------")
    return rmse, mae, r2, predictions

def save_model_artifacts(model, features_list, model_filepath, features_filepath):
    """
    Saves the trained model and the list of features used for training.

    Args:
        model (object): The trained machine learning model.
        features_list (list): List of feature names used for training.
        model_filepath (str): Path to save the trained model.
        features_filepath (str): Path to save the list of feature names.
    """
    os.makedirs(os.path.dirname(model_filepath), exist_ok=True)
    joblib.dump(model, model_filepath)
    print(f"Model saved to {model_filepath}")

    os.makedirs(os.path.dirname(features_filepath), exist_ok=True)
    joblib.dump(features_list, features_filepath)
    print(f"Features list saved to {features_filepath}")

def load_model_artifacts(model_filepath, features_filepath):
    """
    Loads a trained model and its associated feature list.

    Args:
        model_filepath (str): Path to the trained model.
        features_filepath (str): Path to the list of feature names.

    Returns:
        tuple: (object, list): Loaded model and feature list.
    """
    if not os.path.exists(model_filepath):
        raise FileNotFoundError(f"Model file not found at: {model_filepath}")
    if not os.path.exists(features_filepath):
        raise FileNotFoundError(f"Features list file not found at: {features_filepath}")

    model = joblib.load(model_filepath)
    features_list = joblib.load(features_filepath)
    print(f"Model loaded from {model_filepath}")
    print(f"Features list loaded from {features_filepath}")
    return model, features_list

if __name__ == '__main__':
    # Example usage for testing this module independently
    print("Running model_training.py in standalone mode for testing.")
    
    # Create a dummy DataFrame that resembles feature-engineered data
    dummy_data = {
        'Date': pd.to_datetime(['2023-01-01', '2023-01-02', '2023-01-03', '2023-01-04', '2023-01-05',
                               '2023-01-06', '2023-01-07', '2023-01-08', '2023-01-09', '2023-01-10',
                               '2023-01-11', '2023-01-12', '2023-01-13', '2023-01-14', '2023-01-15']),
        'Symbol': ['BTC']*15,
        'Open': np.random.rand(15), 'High': np.random.rand(15), 'Low': np.random.rand(15),
        'Close': np.random.rand(15), 'Volume': np.random.rand(15), 'Marketcap': np.random.rand(15), # Corrected Market Cap
        'Daily_Return': np.random.randn(15) * 0.02,
        'Rolling_Volatility': np.random.rand(15) * 0.1 + 0.01, # Simulate volatility
        'SMA_7': np.random.rand(15), 'SMA_30': np.random.rand(15),
        'Liquidity_Ratio': np.random.rand(15)
    }
    dummy_df = pd.DataFrame(dummy_data)
    
    # Simulate target definition (future volatility)
    df_with_target = define_target_variable(dummy_df.copy(), horizon=1)
    
    # Select features and target
    X, y, features_used = select_features_and_target(df_with_target)

    # Split data into training and testing sets
    # Use shuffle=False for time-series data to maintain chronological order
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=False)

    # Train a model
    trained_model = train_model(X_train, y_train, model_type='RandomForest')

    # Evaluate the model
    rmse, mae, r2, predictions = evaluate_model(trained_model, X_test, y_test)

    # Save model artifacts for later use
    model_path = 'models/test_volatility_predictor.pkl'
    features_path = 'models/test_features_list.pkl'
    save_model_artifacts(trained_model, features_used, model_path, features_path)
    
    # Load and verify
    loaded_model, loaded_features = load_model_artifacts(model_path, features_path)
    print(f"\nLoaded model type: {type(loaded_model)}")
    print(f"Loaded features: {loaded_features}")

    # Clean up dummy files
    os.remove(model_path)
    os.remove(features_path)
    print("\nDummy model artifacts removed.")
