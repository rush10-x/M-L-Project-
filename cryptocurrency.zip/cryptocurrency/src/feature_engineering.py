# src/feature_engineering.py

import pandas as pd
import numpy as np

def calculate_daily_returns(df):
    """
    Calculates daily percentage returns for the 'Close' price.
    Returns: df with 'Daily_Return' column.
    """
    # Calculate daily returns grouped by cryptocurrency symbol
    df['Daily_Return'] = df.groupby('Symbol')['Close'].pct_change()
    print("Daily returns calculated.")
    return df

def calculate_rolling_volatility(df, window=7):
    """
    Calculates rolling historical volatility (standard deviation of daily returns).
    The result is often annualized for comparison, but here we keep it as daily/weekly
    for direct prediction of volatility levels.

    Args:
        df (pd.DataFrame): DataFrame with 'Daily_Return' column.
        window (int): The rolling window size (e.g., 7 for weekly volatility).

    Returns:
        pd.DataFrame: DataFrame with 'Rolling_Volatility' column.
    """
    # Calculate rolling standard deviation of daily returns, grouped by symbol
    df['Rolling_Volatility'] = df.groupby('Symbol')['Daily_Return'].transform(
        lambda x: x.rolling(window=window, min_periods=1).std()
    )
    # Note: min_periods=1 allows calculation even if fewer than 'window' data points exist
    # for the initial part of a series. Adjust if you want strict window size.
    print(f"Rolling volatility calculated with window {window}.")
    return df

def calculate_moving_averages(df, windows=[7, 30]):
    """
    Calculates Simple Moving Averages (SMA) for 'Close' price.

    Args:
        df (pd.DataFrame): DataFrame with 'Close' price.
        windows (list): List of window sizes for SMAs (e.g., [7, 30] for 7-day and 30-day SMAs).

    Returns:
        pd.DataFrame: DataFrame with new SMA columns.
    """
    for window in windows:
        df[f'SMA_{window}'] = df.groupby('Symbol')['Close'].transform(
            lambda x: x.rolling(window=window, min_periods=1).mean()
        )
    print(f"Moving averages calculated for windows {windows}.")
    return df

def calculate_liquidity_ratio(df):
    """
    Calculates a simple liquidity ratio (Volume / Marketcap).
    This can indicate how easily an asset can be bought or sold without affecting its price.

    Args:
        df (pd.DataFrame): DataFrame with 'Volume' and 'Marketcap' columns.

    Returns:
        pd.DataFrame: DataFrame with 'Liquidity_Ratio' column.
    """
    # Corrected 'Market Cap' to 'Marketcap'
    df['Liquidity_Ratio'] = df['Volume'] / (df['Marketcap'] + 1e-9) # Add small epsilon
    
    # Replace infinite values (if any result from division by zero) with NaN, then fill with 0
    df['Liquidity_Ratio'] = df['Liquidity_Ratio'].replace([np.inf, -np.inf], np.nan).fillna(0)
    print("Liquidity ratio calculated.")
    return df

def add_technical_indicators(df):
    """
    Placeholder for adding more advanced technical indicators.
    You might need to install the 'ta' library (pip install ta) for these.
    
    Example indicators you could add:
    - Bollinger Bands (BB)
    - Average True Range (ATR)
    - Relative Strength Index (RSI)
    - Moving Average Convergence Divergence (MACD)

    Args:
        df (pd.DataFrame): The input DataFrame.

    Returns:
        pd.DataFrame: DataFrame with added technical indicators.
    """
    # Example using a hypothetical 'ta' library (you'd need to install it)
    # from ta.volatility import BollingerBands, AverageTrueRange
    # from ta.momentum import RSI
    # from ta.trend import MACD

    # # Ensure 'High', 'Low', 'Close' are available for these calculations
    # if all(col in df.columns for col in ['High', 'Low', 'Close']):
    #     df['BB_upper'] = BollingerBands(close=df['Close'], window=20, window_dev=2).bollinger_hband()
    #     df['BB_lower'] = BollingerBands(close=df['Close'], window=20, window_dev=2).bollinger_lband()
    #     df['BB_middle'] = BollingerBands(close=df['Close'], window=20, window_dev=2).bollinger_mavg()
    #     df['ATR'] = AverageTrueRange(high=df['High'], low=df['Low'], close=df['Close'], window=14).average_true_range()
    #     df['RSI'] = RSI(close=df['Close'], window=14).rsi()
    #     macd = MACD(close=df['Close'], window_fast=12, window_slow=26, window_sign=9)
    #     df['MACD'] = macd.macd()
    #     df['MACD_Signal'] = macd.macd_signal()
    #     print("Advanced technical indicators (BB, ATR, RSI, MACD) added.")
    # else:
    #     print("Warning: Missing 'High', 'Low', or 'Close' columns for advanced technical indicators.")

    print("Consider adding more technical indicators (e.g., using 'ta' library).")
    return df

def engineer_features(df):
    """
    Orchestrates the feature engineering steps.

    Args:
        df (pd.DataFrame): The preprocessed DataFrame.

    Returns:
        pd.DataFrame: DataFrame with all engineered features.
    """
    df = calculate_daily_returns(df)
    df = calculate_rolling_volatility(df, window=7) # You can experiment with different windows
    df = calculate_moving_averages(df, windows=[7, 30]) # You can add more windows
    df = calculate_liquidity_ratio(df)
    df = add_technical_indicators(df) # Call placeholder for advanced indicators

    # After engineering features, some initial rows might have NaN due to rolling window calculations.
    # It's crucial to drop these rows before training the model.
    initial_nan_rows = df.isnull().any(axis=1).sum()
    df.dropna(inplace=True)
    df.reset_index(drop=True, inplace=True)
    print(f"Feature engineering completed. Dropped {initial_nan_rows} rows with NaNs from rolling calculations.")
    return df

if __name__ == '__main__':
    # Example usage for testing this module independently
    print("Running feature_engineering.py in standalone mode for testing.")
    
    # Create a dummy DataFrame that resembles preprocessed data
    dummy_data = {
        'Date': pd.to_datetime(['2023-01-01', '2023-01-02', '2023-01-03', '2023-01-04', '2023-01-05',
                               '2023-01-06', '2023-01-07', '2023-01-08', '2023-01-09', '2023-01-10',
                               '2023-01-01', '2023-01-02', '2023-01-03', '2023-01-04', '2023-01-05',
                               '2023-01-06', '2023-01-07', '2023-01-08', '2023-01-09', '2023-01-10']),
        'Symbol': ['BTC']*10 + ['ETH']*10,
        'Open': np.random.rand(20)*100,
        'High': np.random.rand(20)*100,
        'Low': np.random.rand(20)*100,
        'Close': np.random.rand(20)*100,
        'Volume': np.random.rand(20)*10000,
        'Marketcap': np.random.rand(20)*10000000 # Corrected 'Market Cap' to 'Marketcap'
    }
    dummy_df = pd.DataFrame(dummy_data)
    
    # Simulate a basic preprocessing step (e.g., no NaNs for this test)
    # In a real scenario, this would come from data_processing.py
    processed_df_for_fe = dummy_df.copy()

    features_df = engineer_features(processed_df_for_fe)
    
    print("\nEngineered Features DataFrame Head:")
    print(features_df.head(10))
    print("\nCheck for remaining NaNs after feature engineering:")
    print(features_df.isnull().sum())
