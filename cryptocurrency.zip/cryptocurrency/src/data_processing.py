# src/data_processing.py

import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import numpy as np
import joblib
import os

def load_data(filepath):
    """
    Loads historical cryptocurrency data from a CSV file.

    Args:
        filepath (str): The path to the CSV dataset.

    Returns:
        pd.DataFrame: Loaded and initially sorted DataFrame.
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Dataset not found at: {filepath}")

    df = pd.read_csv(filepath)
    # Ensure 'Date' column is datetime type for proper time-series operations
    df['Date'] = pd.to_datetime(df['Date'])
    # Sort data by symbol and then by date to ensure correct time-series calculations
    df = df.sort_values(by=['Symbol', 'Date']).reset_index(drop=True)
    print(f"Data loaded successfully from {filepath}. Shape: {df.shape}")
    return df

def handle_missing_values(df):
    """
    Handles missing values in the DataFrame.
    
    This implementation uses forward fill followed by backward fill for numerical columns.
    You might need to adjust this strategy based on your dataset's specific missing patterns.

    Args:
        df (pd.DataFrame): The input DataFrame.

    Returns:
        pd.DataFrame: DataFrame with missing values handled.
    """
    # Identify numerical columns to apply fill methods
    numeric_cols = df.select_dtypes(include=np.number).columns
    
    # Apply forward fill (propagates last valid observation forward)
    df[numeric_cols] = df[numeric_cols].ffill()
    
    # Apply backward fill (propagates next valid observation backward)
    # This handles any NaNs at the beginning of the series that ffill would miss
    df[numeric_cols] = df[numeric_cols].bfill()
    
    # After ffill and bfill, if any NaNs remain (e.g., entirely empty columns),
    # consider filling them with a default value like 0 or the mean/median.
    # For this project, we'll assume ffill/bfill are sufficient for time-series data.
    if df[numeric_cols].isnull().sum().sum() > 0:
        print("Warning: Some numerical NaNs still present after ffill/bfill. Consider other strategies.")
        # Example: df[numeric_cols] = df[numeric_cols].fillna(0)

    print("Missing values handled (ffill then bfill for numerical columns).")
    return df

def normalize_features(df, features_to_normalize, scaler_filepath=None):
    """
    Normalizes specified numerical features using MinMaxScaler.
    
    Args:
        df (pd.DataFrame): The input DataFrame.
        features_to_normalize (list): A list of column names to be normalized.
        scaler_filepath (str, optional): Path to save the fitted scaler. If None, scaler is not saved.

    Returns:
        tuple: (pd.DataFrame, MinMaxScaler): DataFrame with normalized features and the fitted scaler.
    """
    scaler = MinMaxScaler()
    
    # Fit the scaler only on the data subset to be normalized
    df[features_to_normalize] = scaler.fit_transform(df[features_to_normalize])
    
    if scaler_filepath:
        os.makedirs(os.path.dirname(scaler_filepath), exist_ok=True)
        joblib.dump(scaler, scaler_filepath)
        print(f"MinMaxScaler saved to {scaler_filepath}")

    print(f"Features {features_to_normalize} normalized.")
    return df, scaler

def preprocess_data(filepath, features_to_normalize, scaler_filepath=None):
    """
    Orchestrates the data preprocessing steps: loading, handling missing values, and normalization.

    Args:
        filepath (str): Path to the raw data CSV.
        features_to_normalize (list): List of numerical features to normalize.
        scaler_filepath (str, optional): Path to save the fitted scaler.

    Returns:
        tuple: (pd.DataFrame, MinMaxScaler): Preprocessed DataFrame and the fitted scaler.
    """
    df = load_data(filepath)
    df = handle_missing_values(df)
    df_processed, scaler = normalize_features(df, features_to_normalize, scaler_filepath)
    return df_processed, scaler

if __name__ == '__main__':
    # Example usage for testing this module independently
    print("Running data_processing.py in standalone mode for testing.")
    
    # Create a dummy CSV for demonstration
    dummy_data = {
        'Date': pd.to_datetime(['2023-01-01', '2023-01-02', '2023-01-03', '2023-01-04', '2023-01-05',
                               '2023-01-01', '2023-01-02', '2023-01-03', '2023-01-04', '2023-01-05']),
        'Symbol': ['BTC']*5 + ['ETH']*5,
        'Open': [100, 102, np.nan, 103, 106, 2000, 2050, 2030, np.nan, 2100],
        'High': [103, 106, 107, 105, 108, 2040, 2080, 2050, 2090, 2120],
        'Low': [99, 101, 104, 102, 105, 1980, 2020, 2010, 2060, 2080],
        'Close': [102, 104, 106, 104, 107, 2030, 2070, 2040, 2080, 2110],
        'Volume': [1000, 1200, 1100, 1300, 1250, 5000, 5500, 5200, 5800, 6000],
        'Market Cap': [2e6, 2.04e6, 2.08e6, 2.04e6, 2.1e6, 1e8, 1.02e8, 1.01e8, 1.03e8, 1.05e8]
    }
    dummy_df = pd.DataFrame(dummy_data)
    
    # Save dummy data to a temporary CSV
    dummy_filepath = 'data/dummy_crypto_prices.csv'
    os.makedirs('data', exist_ok=True)
    dummy_df.to_csv(dummy_filepath, index=False)
    
    features_to_scale = ['Open', 'High', 'Low', 'Close', 'Volume', 'Market Cap']
    processed_df, scaler_obj = preprocess_data(
        dummy_filepath,
        features_to_scale,
        scaler_filepath='models/test_scaler.pkl' # Save scaler for testing
    )
    
    print("\nProcessed DataFrame Head:")
    print(processed_df.head())
    print("\nCheck for remaining NaNs (should be 0 for numerical columns):")
    print(processed_df.isnull().sum())
    
    # Clean up dummy file and scaler
    os.remove(dummy_filepath)
    os.remove('models/test_scaler.pkl')
    print("\nDummy data and test scaler removed.")
