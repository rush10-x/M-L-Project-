# main.py
# This script orchestrates the entire machine learning pipeline:
# 1. Data Preprocessing
# 2. Feature Engineering
# 3. Model Training
# 4. Model Evaluation
# 5. Saving the trained model, scaler, and feature list for deployment.

import os
import pandas as pd
from sklearn.model_selection import train_test_split

# Import functions from our source modules
from src.data_processing import preprocess_data
from src.feature_engineering import engineer_features
from src.model_training import define_target_variable, select_features_and_target, \
                               train_model, evaluate_model, save_model_artifacts

# --- Configuration ---
DATA_FILEPATH = 'data/crypto_prices.csv' # Path to your raw cryptocurrency data
MODELS_DIR = 'models' # Directory to save trained models and artifacts

# Define paths for saving artifacts
MODEL_SAVE_PATH = os.path.join(MODELS_DIR, 'volatility_predictor.pkl')
SCALER_SAVE_PATH = os.path.join(MODELS_DIR, 'data_scaler.pkl')
FEATURES_LIST_SAVE_PATH = os.path.join(MODELS_DIR, 'features_list.pkl')

# Features to be normalized during preprocessing (OHLC, Volume, Marketcap - corrected)
FEATURES_TO_NORMALIZE = ['Open', 'High', 'Low', 'Close', 'Volume', 'Marketcap'] # Corrected 'Market Cap' to 'Marketcap'

# Target variable configuration
TARGET_VOLATILITY_COLUMN = 'Rolling_Volatility' # The feature engineered volatility column
PREDICTION_HORIZON = 1 # Predict volatility 1 day into the future

# Model configuration
MODEL_TYPE = 'RandomForest' # Choose from 'LinearRegression', 'RandomForest', 'GradientBoosting'
TEST_SIZE = 0.2 # Percentage of data to use for testing (e.g., 20%)
RANDOM_STATE = 42 # For reproducibility of data splitting and model training

def run_pipeline():
    """
    Executes the full machine learning pipeline.
    """
    print("--- Starting ML Pipeline ---")

    # 1. Data Preprocessing
    print("\nStep 1: Data Preprocessing...")
    try:
        df_processed, data_scaler = preprocess_data(
            DATA_FILEPATH,
            FEATURES_TO_NORMALIZE,
            scaler_filepath=SCALER_SAVE_PATH # Save the scaler for deployment
        )
        print("Data Preprocessing complete.")
    except FileNotFoundError as e:
        print(f"Error: {e}. Please ensure '{DATA_FILEPATH}' exists.")
        return
    except Exception as e:
        print(f"An error occurred during data preprocessing: {e}")
        return

    # 2. Feature Engineering
    print("\nStep 2: Feature Engineering...")
    # Ensure the 'Marketcap' column is correctly used in feature_engineering functions as well
    df_features = engineer_features(df_processed.copy()) # Use a copy to avoid modifying original processed df
    print("Feature Engineering complete.")

    # 3. Define Target Variable
    print("\nStep 3: Defining Target Variable...")
    # The target will be the future volatility based on the engineered 'Rolling_Volatility'
    df_with_target = define_target_variable(df_features.copy(),
                                            volatility_col=TARGET_VOLATILITY_COLUMN,
                                            horizon=PREDICTION_HORIZON)
    print("Target variable defined.")

    # 4. Select Features and Target for Model
    print("\nStep 4: Selecting Features and Target...")
    # Exclude columns that are not features or are the target itself
    # 'Date' and 'Symbol' are identifiers, 'Daily_Return' is an intermediate calculation
    features_to_exclude = ['Date', 'Symbol', 'Daily_Return', 'Target_Volatility']
    X, y, features_used_for_training = select_features_and_target(df_with_target, exclude_cols=features_to_exclude)
    print(f"Features for model training: {features_used_for_training}")
    print(f"Shape of X: {X.shape}, Shape of y: {y.shape}")

    # 5. Split Data into Training and Testing Sets
    print("\nStep 5: Splitting Data into Training and Testing Sets...")
    # For time-series data, it's crucial to split chronologically, so shuffle=False
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, shuffle=False
    )
    print(f"Training data shape: X_train={X_train.shape}, y_train={y_train.shape}")
    print(f"Testing data shape: X_test={X_test.shape}, y_test={y_test.shape}")

    # 6. Model Training
    print(f"\nStep 6: Training {MODEL_TYPE} Model...")
    trained_model = train_model(X_train, y_train, model_type=MODEL_TYPE)
    print("Model Training complete.")

    # 7. Model Evaluation
    print("\nStep 7: Evaluating Model Performance...")
    rmse, mae, r2, predictions = evaluate_model(trained_model, X_test, y_test)
    print("Model Evaluation complete.")

    # 8. Save Model Artifacts
    print("\nStep 8: Saving Model Artifacts...")
    save_model_artifacts(trained_model, features_used_for_training, MODEL_SAVE_PATH, FEATURES_LIST_SAVE_PATH)
    print("Model artifacts saved successfully.")

    print("\n--- ML Pipeline Completed Successfully ---")

if __name__ == '__main__':
    # Ensure the 'models' directory exists
    os.makedirs(MODELS_DIR, exist_ok=True)
    run_pipeline()
